export enum AlertType {
  SUCCESS = 'success',
  DANGER = 'danger'
}

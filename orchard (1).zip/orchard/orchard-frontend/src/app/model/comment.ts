export class Comment {
  id: number;
  username: string;
  content: string;
  postId: number;
  postedDate: Date;
}

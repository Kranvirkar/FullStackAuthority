export class PasswordChange {
  public username: string;
  public currentPassword: string;
  public newPassword: string;
  public confirmPassword: string;
}
